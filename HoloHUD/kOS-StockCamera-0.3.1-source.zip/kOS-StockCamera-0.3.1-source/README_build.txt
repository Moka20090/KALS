kOS StockCamera 0.3.1 -- UNOFFICIAL BUILD (2026-09-26)
=======================================================

WHAT THIS IS
  The kOS addon that adds ADDONS:CAMERA to kOS, including FREECAMERA (full-pose camera control), which
  hud_test.ks and the planned HUD need. CKAN only carries v0.2 (no FREECAMERA). 0.3.0 / 0.3.1 exist only
  as unreleased source upstream, so this folder holds a build of that source.

  Source:   https://github.com/KSP-KOS/KOS-StockCamera, branch master, commit
            45d75aa7c4160bb5f9ad07183853b3b8a1c9a3b5 (2026-05-11, "Freecamera adjustments and new camera
            light (#9)"), which is the CHANGELOG's "v0.3.1 unreleased". Labelled 0.3.1.0 at build time.
  Built:    2026-09-26 with the .NET SDK 8.0.425, against KSP 1.12.5 (build 03190) and kOS 1.6.0.1.
  Reviewed: the C# source has no network, process, file, reflection, native or registry access.

  kOS.AddOns.StockCamera.dll  59,392 bytes
  SHA256  67F7CF0F8B1C139A2316EA93995423604C1D25AC74BA98F9D5AD3073638752F7

INSTALL INTO A KSP INSTALL
  1. In CKAN, uninstall "kOS StockCamera" if it is installed (v0.2), so there are not two copies.
  2. Copy GameData\kOS-Addons\StockCamera from this folder into that install's GameData\ (so it ends up as
     <install>\GameData\kOS-Addons\StockCamera\kOS.AddOns.StockCamera.dll + KOS-StockCamera.version).
  3. In kOS, the first lines of hud_test.ks should say "free camera found".
  CKAN will list the DLL as unmanaged / auto-detected; do not let it reinstall v0.2.
  Undo: delete <install>\GameData\kOS-Addons\StockCamera and reinstall v0.2 from CKAN.

  The DLL is compiled against kOS 1.6.0.1. If an install runs a DIFFERENT kOS version, rebuild for it:

REBUILD FOR ANOTHER INSTALL (e.g. SolQuarter)
  Needs the .NET SDK 8.x (dotnet --list-sdks). From Git Bash, in this folder:
      ./build_stockcamera.sh "C:/Kerbal Space Program - SolQuarter"
  Nothing is downloaded: the three NuGet packages are in nuget_pkgs\ (KSPBuildTools 1.1.1, Krafs.Publicizer
  2.2.1, JsonPoke 1.2.0), and kos_stockcamera\nuget.config allows only those three ids anyway. The script
  never runs CKAN (KSPBuildTools would, by default) and only READS the KSP folder. The new DLL lands in
  kos_stockcamera\GameData\kOS-Addons\StockCamera -- then install it as above.

WHEN UPSTREAM RELEASES 0.3.x
  Prefer the official release (CKAN / GitHub Releases) and retire this folder.
