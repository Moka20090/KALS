#!/bin/bash
# Rebuilds kOS StockCamera from the source in ./kos_stockcamera (master 45d75aa, "0.3.1", unreleased upstream)
# against the KSP install given as $1 (default: the JNSQ install). Run from Git Bash:
#     ./build_stockcamera.sh "C:/Kerbal Space Program - SolQuarter"
# Needs the .NET SDK (8.x). NuGet packages come from ./nuget_pkgs (KSPBuildTools 1.1.1, Krafs.Publicizer 2.2.1,
# JsonPoke 1.2.0); kos_stockcamera/nuget.config maps ONLY those three ids to nuget.org, so nothing else can be
# downloaded. Output: kos_stockcamera/GameData/kOS-Addons/StockCamera (copy that folder into the install).
#   KSPBT_InstallCKANDependencies=false  -- otherwise KSPBuildTools runs `ckan update` + `ckan install kOS` on the game
#   AutomaticallyUseReferenceAssemblyPackages=false, DisableTransitiveFrameworkReferenceDownloads=true -- KSPBuildTools'
#       own settings, passed from the start: compile against KSP's Managed DLLs, no 19.4 MB reference-assembly package
#   KSPBT_ModVersion=0.3.1  -- upstream sets the version in its release pipeline; without it the DLL says 1.0.0.0
# The KSP folder is only READ (references). Built 2026-09-26 against KSP 1.12.5 + kOS 1.6.0.1.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
KSP="${1:-C:/Kerbal Space Program - JNSQ/Kerbal Space Program - Copy}"
[ -f "$KSP/KSP_x64_Data/Managed/Assembly-CSharp.dll" ] || { echo "not a KSP install: $KSP"; exit 1; }
[ -f "$KSP/GameData/kOS/Plugins/kOS.dll" ] || { echo "no kOS in: $KSP/GameData/kOS/Plugins"; exit 1; }
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1 DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1
export DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE=1 DOTNET_GENERATE_ASPNET_CERTIFICATE=false
export NUGET_PACKAGES="$HERE/nuget_pkgs"
PROJ="src/kOS.Addons.StockCamera/kOS.AddOns.StockCamera.csproj"
PROPS=(-p:KSPBT_ModVersion=0.3.1 -p:NuGetAudit=false -p:KSPBT_GameRoot="$KSP" -p:KSPBT_InstallCKANDependencies=false
       -p:AutomaticallyUseReferenceAssemblyPackages=false -p:DisableTransitiveFrameworkReferenceDownloads=true)
cd "$HERE/kos_stockcamera"
echo "--- building against: $KSP"
echo "--- SDKs:"; dotnet --list-sdks
dotnet restore "$PROJ" "${PROPS[@]}"
echo "--- packages (must be exactly jsonpoke, krafs.publicizer, kspbuildtools):"
for d in "$NUGET_PACKAGES"/*/; do echo "   $(basename "$d") $(ls "$d")"; done
dotnet build "$PROJ" -c Release --no-restore "${PROPS[@]}"
echo "--- output:"; find GameData -type f -exec ls -l {} \;
